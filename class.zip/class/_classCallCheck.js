'use strict';

/**
 * @tested
 */

module.exports = (function(){

function _classCallCheck(instance, Constructor){
    if(!(instance instanceof Constructor)){ //거의 쓸 필요가 없는 _instanceof 함수 참조 제거.
        throw new TypeError("Cannot call a class as a function");
    }
}


return _classCallCheck;
})();